package com.jarvis.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class HeartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var pulseRadius = 0f
    private val outerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5FF")
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }
    private val innerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00B0FF")
        style = Paint.Style.FILL
        alpha = 70
    }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E0F7FA")
        style = Paint.Style.FILL
    }

    init {
        val animator = ValueAnimator.ofFloat(0.85f, 1.15f).apply {
            duration = 1200
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                val scale = it.animatedValue as Float
                val base = Math.min(width, height) / 3f
                pulseRadius = base * scale
                invalidate()
            }
        }
        post { animator.start() }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = if (pulseRadius > 0) pulseRadius else Math.min(cx, cy) * 0.7f

        // Draw pulsing outer glow
        canvas.drawCircle(cx, cy, r, innerPaint)
        canvas.drawCircle(cx, cy, r, outerPaint)
        // Center core
        canvas.drawCircle(cx, cy, r * 0.4f, corePaint)
    }
}
