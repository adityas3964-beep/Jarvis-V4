package com.jarvis.app

import android.content.Context
import android.content.Intent

object Commands {
    fun execute(context: Context, text: String): String {
        val cmd = text.lowercase().trim()
        val acc = JarvisAccessibility.instance

        return when {
            cmd.contains("next") || cmd.contains("scroll down") || cmd.contains("aage") -> {
                if (acc != null && acc.swipe(true)) "Scrolling down" else "Accessibility not enabled"
            }
            cmd.contains("previous") || cmd.contains("scroll up") || cmd.contains("peeche") -> {
                if (acc != null && acc.swipe(false)) "Scrolling up" else "Accessibility not enabled"
            }
            cmd.contains("like") -> {
                if (acc != null && acc.like()) "Liked" else "Could not like"
            }
            cmd.contains("open youtube") -> {
                val intent = context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                if (intent != null) {
                    context.startActivity(intent)
                    "Opening YouTube"
                } else "YouTube not found"
            }
            cmd.contains("open instagram") -> {
                val intent = context.packageManager.getLaunchIntentForPackage("com.instagram.android")
                if (intent != null) {
                    context.startActivity(intent)
                    "Opening Instagram"
                } else "Instagram not found"
            }
            cmd.contains("reels") -> {
                JarvisAccessibility.setPending("reels")
                val intent = context.packageManager.getLaunchIntentForPackage("com.instagram.android")
                if (intent != null) {
                    context.startActivity(intent)
                    "Opening Reels"
                } else "Instagram not found"
            }
            cmd.contains("shorts") -> {
                JarvisAccessibility.setPending("shorts")
                val intent = context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                if (intent != null) {
                    context.startActivity(intent)
                    "Opening Shorts"
                } else "YouTube not found"
            }
            else -> "Command not recognized: $text"
        }
    }
}
