# Jarvis Assistant AI

Android voice & gesture assistant app with offline speech recognition and accessibility automation.
